# Product Email Theme

## Description

A stylish, clean and responsive template designed to help you have a completely customized email in a simple way.

## Install

All you have to do is download the zip file, access ```Settings > Themes```, and upload the theme.

---

# Tema de Email de Produto

## Descrição

Um template com design elegante, limpo e responsivo, preparado para ajudar você a ter um email completamente customizado de forma simples.

## Instalação

Basta apenas que você faça o download do aquivo zip, acessar ```Configurações > Temas```, e fazer o upload do tema.